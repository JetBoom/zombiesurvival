ENT.Type = "anim"
ENT.Base = "status__base"
