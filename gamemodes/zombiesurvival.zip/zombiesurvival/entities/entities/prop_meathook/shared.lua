ENT.Type = "anim"

ENT.NoReviveFromKills = true
