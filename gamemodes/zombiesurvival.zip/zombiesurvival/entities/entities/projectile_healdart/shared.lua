ENT.Type = "anim"

AccessorFuncDT(ENT, "HitTime", "Float", 0)
