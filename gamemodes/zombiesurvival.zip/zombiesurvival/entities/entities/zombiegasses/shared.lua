ENT.Type = "anim"

AccessorFuncDT(ENT, "Radius", "Float", 0)
