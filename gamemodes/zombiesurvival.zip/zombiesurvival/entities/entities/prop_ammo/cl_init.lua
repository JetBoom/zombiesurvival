include("shared.lua")

ENT.ColorModulation = Color(0.25, 1, 0.25)
