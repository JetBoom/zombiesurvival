AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "status_ghost_base"

ENT.GhostModel = Model("models/props_combine/combine_light001a.mdl")
ENT.GhostRotation = Angle(270, 180, 0)
ENT.GhostHitNormalOffset = 0
ENT.GhostEntity = "prop_spotlamp"
ENT.GhostWeapon = "weapon_zs_spotlamp"
ENT.GhostDistance = 200
ENT.GhostLimitedNormal = 0.75
