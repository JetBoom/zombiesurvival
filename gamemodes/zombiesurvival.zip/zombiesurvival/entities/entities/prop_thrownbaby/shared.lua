ENT.Type = "anim"

ENT.NoNails = true

AccessorFuncDT(ENT, "Settled", "Bool", 0)
