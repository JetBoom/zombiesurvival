ENT.Type = "anim"

ENT.Damage = 100
