include('shared.lua')

SWEP.Slot = -1
SWEP.SlotPos = -1
SWEP.DrawAmmo = false					
SWEP.DrawCrosshair = true 					
SWEP.DrawWeaponInfoBox = false

