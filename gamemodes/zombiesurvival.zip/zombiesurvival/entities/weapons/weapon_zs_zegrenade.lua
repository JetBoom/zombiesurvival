AddCSLuaFile()

SWEP.Base = "weapon_zs_grenade"

SWEP.WalkSpeed = SPEED_ZOMBIEESCAPE_NORMAL

SWEP.GrenadeDamage = 1280
SWEP.GrenadeRadius = 256
