AddCSLuaFile()

SWEP.Base = "weapon_zs_akbar"

SWEP.Primary.Damage = 85

SWEP.ConeMax = 0.05
SWEP.ConeMin = 0.02

SWEP.WalkSpeed = SPEED_ZOMBIEESCAPE_SLOW

SWEP.Primary.KnockbackScale = ZE_KNOCKBACKSCALE
SWEP.Primary.DefaultClip = 99999
