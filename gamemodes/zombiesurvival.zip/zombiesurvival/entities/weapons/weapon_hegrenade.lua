AddCSLuaFile()

SWEP.Base = "weapon_zs_zegrenade"
