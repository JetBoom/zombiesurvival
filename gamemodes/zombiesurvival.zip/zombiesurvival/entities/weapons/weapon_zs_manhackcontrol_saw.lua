AddCSLuaFile()

SWEP.Base = "weapon_zs_manhackcontrol"

if CLIENT then
	SWEP.PrintName = "Manhack Control - Saw"
	SWEP.Description = "Controller for your modified Manhack."
end

SWEP.EntityClass = "prop_manhack_saw"
