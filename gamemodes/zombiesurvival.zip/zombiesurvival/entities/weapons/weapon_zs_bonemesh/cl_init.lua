include("shared.lua")

SWEP.PrintName = "Bone Mesh"
SWEP.ViewModelFOV = 47
SWEP.DrawCrosshair = false

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
end
