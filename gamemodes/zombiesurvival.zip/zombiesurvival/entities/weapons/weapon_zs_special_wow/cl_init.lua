include("shared.lua")

SWEP.PrintName = "Will O' Wisp"
SWEP.DrawCrosshair = false
