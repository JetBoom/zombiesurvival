AddCSLuaFile()

SWEP.Base = "weapon_zs_sweepershotgun"

SWEP.Primary.Damage = 70

SWEP.Primary.DefaultClip = 99999
SWEP.Primary.KnockbackScale = ZE_KNOCKBACKSCALE

SWEP.WalkSpeed = SPEED_ZOMBIEESCAPE_SLOWER
