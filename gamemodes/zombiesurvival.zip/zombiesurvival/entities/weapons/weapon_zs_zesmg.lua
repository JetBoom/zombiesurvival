AddCSLuaFile()

SWEP.Base = "weapon_zs_smg"

SWEP.Primary.Damage = 75

SWEP.ConeMax = 0.06
SWEP.ConeMin = 0.04

SWEP.WalkSpeed = SPEED_ZOMBIEESCAPE_SLOW

SWEP.Primary.KnockbackScale = ZE_KNOCKBACKSCALE
SWEP.Primary.DefaultClip = 99999
